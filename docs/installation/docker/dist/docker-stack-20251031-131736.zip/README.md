﻿# Docker Stack Deployment

This ZIP file contains a complete Docker stack deployment for:
- **Neo4j** - Graph database
- **Milvus** - Vector database  
- **MQTT** - Message broker

## Quick Start

1. **Extract** this ZIP file to your desired installation directory
2. **Copy** the `docker-stack-installer.ps1` script to the same directory
3. **Run** the installer: `.\docker-stack-installer.ps1`
4. **Follow** the interactive prompts to configure each service

## What's Included

### Services
- **neo4j/** - Neo4j graph database with Cypher scripts
- **milvus/** - Milvus vector database with configuration
- **mqtt/** - MQTT message broker with SSL support

### Installation
- **Installer script not included** - Copy `docker-stack-installer.ps1` separately

### Features
- Interactive configuration for all services
- SSL/TLS support for secure connections
- Automatic password generation
- Comprehensive management scripts
- Backup and restore capabilities

## Requirements

- **Docker Desktop** - Must be installed and running
- **PowerShell 5.0+** - For running installation scripts
- **Windows 10/11** - Tested on Windows environments

## Service Access (after installation)

### Neo4j
- Browser UI: http://localhost:7474
- Bolt Protocol: bolt://localhost:7687
- HTTPS (if SSL enabled): https://localhost:7473

### Milvus  
- gRPC API: localhost:19530
- HTTP API: localhost:9091
- MinIO Console: http://localhost:9001

### MQTT
- Broker: localhost:1883
- WebSocket: ws://localhost:9002
- SSL (if enabled): localhost:8883

## Management

Each service includes management scripts in their respective management/ folders:
- install.ps1 - Service installation and configuration
- ackup.ps1 - Create service backups
- estore.ps1 - Restore from backups
- manage-ssl.ps1 - SSL certificate management (Neo4j/Milvus/MQTT)
- manage-users.ps1 - User management (MQTT)

## Support

For issues or questions, refer to the documentation in each service directory.

---
Generated: 2025-10-31 13:17:36
